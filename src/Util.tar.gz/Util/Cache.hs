module Util.Cache where

import Struct.Struct
import Data.Queue
import Control.Concurrent.STM
import Control.Concurrent
import Control.Monad 

requestMonitor :: TVar String -> IO ()
requestMonitor request = do
  createQueue
  forever $ do
    readRequest . parseRequest . verifyUnique
    --  case true
--       writeReqtoQueue
--  else
--       addReftoExistingReq
--  liftIO $ threadDelay 1000000


createQueue =
  undefined

readRequest :: TVar String -> String
readRequest r =
  undefined

parseRequest :: String -> Map -> [Params]
parseRequest r =
  undefined

verifyUnique =
  undefined
