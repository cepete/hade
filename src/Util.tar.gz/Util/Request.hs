module Util.Request where

import Struct.Struct
import Control.Concurrent.STM
import Control.Concurrent
import Control.Monad 
import qualified Data.Sequence as S
import Data.Sequence((<|), (|>), (><), ViewL(..), ViewR(..))

requestMonitor :: Req -> String
requestMonitor request = do
  forever $ do
    (readRequest request) . parseRequest
    --  case true
--       writeReqtoQueue
--  else
--       addReftoExistingReq
--  liftIO $ threadDelay 1000000


readRequest :: Req -> String
readRequest r =
  undefined

parseRequest :: String -> PReq 
parseRequest r =
  undefined

writeReqtoQueue :: PReq
writeReqtoQueue p =
  undefined

--verifyUnique :: PReq -> String 
--verifyUnique m =
--  undefined
